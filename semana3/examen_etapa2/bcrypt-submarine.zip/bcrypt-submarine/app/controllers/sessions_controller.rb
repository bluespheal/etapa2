# GETS ============================================

get '/signin' do
	erb :signin
end

get '/logout' do
  #¿Qué va en esta parte para cerrar la sesión?
	
end

# POSTS ============================================

post '/signin' do
  #¿Qué va en esta parte para ingresar al juego?

	if @user
  	
  else
  	
  end

end
