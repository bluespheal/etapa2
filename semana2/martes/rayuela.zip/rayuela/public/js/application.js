$(document).ready(function() {
	// Tu código va aquí

});
